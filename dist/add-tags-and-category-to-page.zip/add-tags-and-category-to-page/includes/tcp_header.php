<div class="wrap">
<h2>Add Tags and Category to Page and Post Type</h2><br/>
<table width="100%">
	<tr>
    	<td valign="top">          