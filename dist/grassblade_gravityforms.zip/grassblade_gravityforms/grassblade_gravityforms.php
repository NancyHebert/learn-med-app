<?php
/*
 Plugin Name: GrassBlade Gravity Forms Addon
 Plugin URI: http://www.nextsoftwaresolutions.com
 Description: GrassBlade Gravity Forms Addon
 Author: Pankaj Agrawal
 Author URI: http://www.nextsoftwaresolutions.com
 Version: 0.1
 */

	class grassblade_gravityforms {
		public $debug = false;
		
		function __construct() {
			add_action('gform_after_submission', array($this, 'gbgf_gravityforms_submission'), 10, 2);
		}
		function gbgf_gravityforms_submission($entry, $form) {
			//$cmi->debug(serialize(array('entry' => $entry, 'form' => $form)));
			//$cmi->debug(array('entry' => $entry, 'form' => $form));
			require_once(dirname(__FILE__)."/nss_cmi_xapi.class.php");
		    $grassblade_tincan_endpoint = get_option( 'grassblade_tincan_endpoint' );
			$grassblade_tincan_user = get_option('grassblade_tincan_user');
			$grassblade_tincan_password = get_option('grassblade_tincan_password');
			$grassblade_tincan_track_guest = get_option('grassblade_tincan_track_guest');		
			
			$cmi = new NSS_CMI_XAPI($grassblade_tincan_endpoint, $grassblade_tincan_user, $grassblade_tincan_password);
			
			$actor = grassblade_getactor($grassblade_tincan_track_guest);
			$cmi->debug(array("Actor" => $actor));
			
			if(empty($actor))
			{
				$cmi->debug("No Actor. Shutting Down.");
				return;
			}
			
			$this->attempted($cmi, $actor, $entry, $form);
			$this->answered($cmi, $actor, $entry, $form);
			$this->completed($cmi, $actor, $entry, $form);
			foreach($cmi->statements as $statement)
			{
				$ret = $cmi->SendStatements(array($statement));
				$cmi->debug($statement);
				$cmi->debug($ret);
			}
		}
		function attempted($cmi, $actor, $entry, $form) {
			$cmi->set_verb('attempted');
			$cmi->set_actor_by_object($actor);
			$cmi->set_parent($entry['source_url'], $form['title'], $form['description'], 'http://adlnet.gov/expapi/activities/course','Activity');
			$cmi->set_grouping($entry['source_url'], $form['title'], $form['description'], 'http://adlnet.gov/expapi/activities/course','Activity');
			$cmi->set_object($entry['source_url'], $form['title'], $form['description'], 'http://adlnet.gov/expapi/activities/course','Activity');
			$statement = $cmi->build_statement();
			//$cmi->debug($statement);
			$cmi->new_statement();
		}
		function completed($cmi, $actor, $entry, $form) {
			$cmi->set_verb('completed');
			$success = ($entry['gquiz_is_pass'])? true:false;
			
			$cmi->set_actor_by_object($actor);
			
			$result = array(
						'score' => array(
								'raw' => $entry['gquiz_score'],
								'min' => 0,
								'scaled' => $entry['gquiz_percent']/100,
								),
			/*			'extension' => array(
								'grade' => $entry['gquiz_grade'],
								'percent' => $entry['gquiz_percent']
								),*/
						'success' => $success
						);
			$cmi->debug($result);
			$cmi->set_parent($entry['source_url'], $form['title'], $form['description'], 'http://adlnet.gov/expapi/activities/course','Activity');
			$cmi->set_grouping($entry['source_url'], $form['title'], $form['description'], 'http://adlnet.gov/expapi/activities/course','Activity');
			$cmi->set_object($entry['source_url'], $form['title'], $form['description'], 'http://adlnet.gov/expapi/activities/course','Activity');
			$cmi->set_result_by_object($result);
			$statement = $cmi->build_statement();
			//$cmi->debug($statement);
			$cmi->new_statement();
		}		
		function answered($cmi, $actor, $entry, $form) {
			foreach($form['fields'] as $answer) {
				$cmi->debug($answer);
				
				$id = $answer['id'];
				$gquizFieldType = !empty($answer['gquizFieldType'])? $answer['gquizFieldType']:"";
				$question = $answer['label'];
				$cmi->debug($id.". ".$question);
				
				$correctResponse = "";
				$choices = array();
				if(!empty($answer['choices']))
				{
					$choices = array();
					foreach($answer['choices'] as $choice) {
						if(!empty($choice['gquizIsCorrect']) && !empty($choice['text'])) {
							if(empty($correctResponse))
							$correctResponse = $choice['text'];
							else
							$correctResponse .= "[,]".$choice['text'];
						}
						$choices[$choice['text']] = $choice['text'];
						$choices_ids[$choice['value']] = $choice['text'];
					}
				}
				$cmi->debug(array('correctResponse' => $correctResponse, 'choices' => $choices));
				
				if(is_array($answer['inputs']))
				{
					$response = '';
					foreach($answer['inputs'] as $input) {
						$cmi->debug($input);
						$iid = (string) $input['id'];
						$cmi->debug($iid);
						$cmi->debug($entry[$iid]);
						
						if(empty($response))
						$response = isset($choices_ids[$entry[$iid]])? $choices_ids[$entry[$iid]]:$entry[$iid];
						else if($entry[$iid] != '')
						$response .= '[,]'.(isset($choices_ids[$entry[$iid]])? $choices_ids[$entry[$iid]]:$entry[$iid]);
						$cmi->debug($response);
					}
					$response = trim($response);
				}
				else
				$response = isset($choices_ids[$entry[$id]])? $choices_ids[$entry[$id]]:$entry[$id];
				$cmi->debug(array('Response' => $response));
				
				$cmi->set_verb('answered');
				$cmi->set_actor_by_object($actor);
				$cmi->set_parent($entry['source_url'].'/assessment/', $form['title'], $form['description'], 'http://adlnet.gov/expapi/activities/assessment','Activity');
				$cmi->set_grouping($entry['source_url'], $form['title'], $form['description'], 'http://adlnet.gov/expapi/activities/course','Activity');
				$question_id = $entry['source_url'].'/assessment/interactions.'.$id;
				
				if($gquizFieldType == "checkbox" && count($answer['inputs']) == 2 && (($answer['inputs'][0]['label'] == 'True' && $answer['inputs'][0]['label'] == 'False') || ($answer['inputs'][0]['label'] == 'False' && $answer['inputs'][0]['label'] == 'True')))
				{
					$cmi->debug("This is True-False Type");

					if($answer['choices'][0]['gquizIsCorrect'] == '1')
					$correctResponse = $answer['choices'][0]['text'];
					else if($answer['choices'][1]['gquizIsCorrect'] == '1')
					$correctResponse = $answer['choices'][1]['text'];
					$cmi->set_object_type_true_false($question_id, $question, strtolower($correctResponse));
				}
				else
				{
					$cmi->debug("This is NOT True-False Type");
					switch($gquizFieldType) {
						case 'radio':
						case 'select':
						case 'checkbox';
								$cmi->set_object_type_choice($question_id, $question, $correctResponse, $choices);
								break;
						default:
								$cmi->set_object_type_fill_in($question_id, $question, $correctResponse);
					}
				}
				if(!empty($correctResponse))
					$cmi->set_result_by_response($response);
				else
					$cmi->set_result_by_object(array('response' => str_replace("[,]", " ", $response)));
					
				$statement = $cmi->build_statement();
				$cmi->debug($statement);
				$cmi->new_statement();
			}
		}

	}

	add_action('init', 'nss_plugin_updater_activate_grassblade_gravityforms');

	function nss_plugin_updater_activate_grassblade_gravityforms()
	{
		if(!class_exists('nss_plugin_updater'))
		require_once ('wp_autoupdate.php');
		
		$nss_plugin_updater_plugin_remote_path = 'http://www.nextsoftwaresolutions.com/';
		$nss_plugin_updater_plugin_slug = plugin_basename(__FILE__);

		new nss_plugin_updater ($nss_plugin_updater_plugin_remote_path, $nss_plugin_updater_plugin_slug);
	}


	require_once(dirname(dirname(__FILE__)).'/grassblade/addons/nss_xapi_verbs.class.php');
	require_once(dirname(dirname(__FILE__)).'/grassblade/addons/nss_xapi.class.php');
	$gb = new grassblade_gravityforms();
	