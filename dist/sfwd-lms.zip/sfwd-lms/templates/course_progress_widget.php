<dd class="course_progress" title="<?php echo sprintf(__("%s out of %s steps completed", "learndash"),$completed, $total); ?>">
	<div class="course_progress_blue" style="width: <?php echo $percentage; ?>%;"> 
</dd>