<dd class="course_progress" title="<?php echo $message; ?>">
	<div class="course_progress_blue" style="width: <?php echo $percentage; ?>%;"> 
</dd>