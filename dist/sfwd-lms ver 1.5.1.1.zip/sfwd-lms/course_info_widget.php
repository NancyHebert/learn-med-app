<?php

class LearnDash_Course_Info_Widget extends WP_Widget {

	function LearnDash_Course_Info_Widget() {
		$widget_ops = array('classname' => 'widget_ldcourseinfo', 'description' => __('LearnDash - Course attempt and score information of users. Visible only to users logged in.', 'learndash'));
		$control_ops = array();//'width' => 400, 'height' => 350);
		$this->WP_Widget('ldcourseinfo', __('Course Information', 'learndash'), $widget_ops, $control_ops);
	}

	function widget( $args, $instance ) {

		extract($args);
		$title = apply_filters( 'widget_title', empty($instance['title']) ? '' : $instance['title'], $instance );

		if(empty($user_id))
		{
			$current_user = wp_get_current_user();
			if(empty($current_user->ID))
			return;
		
			$user_id = $current_user->ID;
		}	
		
		$courseinfo = learndash_course_info($user_id);
		
		if(empty($courseinfo))
		return;
		
		echo $before_widget;
		if ( !empty( $title ) ) { echo $before_title . $title . $after_title; } 
		
		echo $courseinfo;
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);

		return $instance;
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '') );
		$title = strip_tags($instance['title']);
		//$text = format_to_edit($instance['text']);
		?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'learndash'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
		<?php
	}
}

class LearnDash_Course_Navigation_Widget extends WP_Widget {

	function LearnDash_Course_Navigation_Widget() {
		$widget_ops = array('classname' => 'widget_ldcoursenavigation', 'description' => __('LearnDash - Course Navigation. Shows lessons on a course.', 'learndash'));
		$control_ops = array();//'width' => 400, 'height' => 350);
		$this->WP_Widget('widget_ldcoursenavigation', __('Course Navigation', 'learndash'), $widget_ops, $control_ops);
	}

	function widget( $args, $instance ) {
		global $post;
		
		if(empty($post->ID) || !is_single())
		return;
		
		$course_id = learndash_get_course_id($post->ID);
		if(empty($course_id))
		return;
		
		extract($args);
		$title = apply_filters( 'widget_title', empty($instance['title']) ? '' : $instance['title'], $instance );

		$coursenavigation = learndash_course_navigation($course_id);
		
		if(empty($coursenavigation))
		return;
		
		echo $before_widget;
		if ( !empty( $title ) ) { echo $before_title . $title . $after_title; } 
		
		echo $coursenavigation;
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);

		return $instance;
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '') );
		$title = strip_tags($instance['title']);
		//$text = format_to_edit($instance['text']);
		?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'learndash'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
		<?php
	}
}

function learndash_course_navigation($course_id) {
	$course = get_post($course_id);
	
	if(empty($course->ID) || $course_id != $course->ID)
	return;
	
	$terms = wp_get_post_terms( $course_id, 'courses' );
	$slug = $terms[0]->slug;
	
	if(empty($slug))
	return;
	
	$html = "<div id='course_navigation'>";
	$html .= "<a id='course_navigation_course_link' href='".get_permalink($course_id)."'>".$course->post_title."</a>";
	$course_lesson_orderby = learndash_get_setting($course_id, 'lesson_orderby');
	$course_lesson_order = learndash_get_setting($course_id, 'lesson_order');
	$lessons = sfwd_lms_get_post_options( 'sfwd-lessons' );							
	$orderby = (empty($course_lesson_orderby))? $lessons['orderby']:$course_lesson_orderby;
	$order = (empty($course_lesson_order))? $lessons['order']:$course_lesson_order;
	$lessons = wptexturize(do_shortcode("[sfwd-lessons tax_terms='{$slug}' order='{$order}' orderby='{$orderby}' posts_per_page='{$lessons['posts_per_page']}']"));
	$html .= $lessons;
	$html .= "</div>";
	return $html;
}
//add_action('widgets_init', create_function('', 'return register_widget("LearnDash_Course_Navigation_Widget");'));

function learndash_course_info($user_id){
	return SFWD_LMS::get_course_info($user_id);
}
add_action('widgets_init', create_function('', 'return register_widget("LearnDash_Course_Info_Widget");'));

function learndash_course_info_shortcode($atts){
	
	if(isset($atts['user_id']))
	$user_id = $atts['user_id'];
	else
	{
	$current_user = wp_get_current_user();

	if(empty($current_user->ID))
	return;
	
	$user_id = $current_user->ID;
	}	
	return SFWD_LMS::get_course_info($user_id);
}
add_shortcode('ld_course_info', 'learndash_course_info_shortcode');