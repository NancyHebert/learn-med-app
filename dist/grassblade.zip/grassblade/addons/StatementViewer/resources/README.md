#Project Tin Can Prototypes
###Contact:
* tincan@scorm.com
* http://scorm.com/tincan

##Overview

###This package contains a statement viewing page for the Tin Can API.

 * Copy the file config.js.template to config.js 
and set Config.endpoint to the LRS endpoint, including a trailing slash (ex: https://cloud.scorm.com/ScormEngineInterface/TCAPI/public/)
 * Verify the LRS endpoint in your browser by navigating to the URL: &lt;endpoint&gt;/statements?limit=1
 * Launch: index.html
