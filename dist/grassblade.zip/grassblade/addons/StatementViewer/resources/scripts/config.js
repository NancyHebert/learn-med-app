		function Config() {
			"use strict";
		}
		Config.endpoint = GrassBladeConfig.endpoint;
		Config.authUser = GrassBladeConfig.user;
		Config.authPassword = GrassBladeConfig.pass;
		Config.actor = { "mbox":["TestEmail@domain.com"], "name":["Test Name"] };
		Config.registration = "1111-1111-1111-1111";
		
		jQuery(document).ready(function(){
                TC_VIEWER = new TINCAN.Viewer();
                TC_VIEWER.pageInitialize();
                TC_VIEWER.searchStatements();
        });