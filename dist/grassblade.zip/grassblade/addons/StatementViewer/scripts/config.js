		function Config() {
			"use strict";
		}
		Config.endpoint = GrassBladeConfig.endpoint;
		Config.user = GrassBladeConfig.user;
		Config.password = GrassBladeConfig.pass;
		Config.actor = { "mbox":["TestEmail@domain.com"], "name":["Test Name"] };